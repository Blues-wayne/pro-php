<?php
	class Template{
		//模板列表
		function index(){
			$this->mess("以下为前端模板文件.<br/>请确认您具备一定的代码编辑能力再进行模板编辑.");
			$this->templatelist();
			$this->display();
		}
		
		function template(){
			$this->mess("如果您不具备代码编辑能力，请谨慎操作以免造成页面混乱.");
			$filename=$_POST['path'];
			$file = htmlspecialchars(file_get_contents($filename));
			$this->assign('file',$file);
			$this->assign('path',$filename);
			$this->display();
		}
		
		function update(){
			$this->mess("模板修改成功.",true);
			//$content = str_replace(array("\"","'"),array("&quot;","&#039;"),stripslashes($_POST['content']));
			//file_put_contents($_POST['path'], str_replace(array("&quot;","&#039;"),array("\"","'"),stripslashes($_POST['content'])));
			file_put_contents($_POST['path'], stripslashes($_POST['content']));
			$this->templatelist();
			$this->display('index');
/* 			$content = str_replace("\\","",stripslashes($_POST['content']));
 			file_put_contents($_POST['path'], $content);
			$this->templatelist();
			$this->display('index');  */
		}
		
		private function list_dir($dir){
			$result = array();
			if (is_dir($dir)){
				$file_dir = scandir($dir);//返回目录列表中的文件及目录名称
				foreach($file_dir as $file){
					if ($file == '.' || $file == '..'){
						continue;
					}
					elseif (is_dir($dir.$file)){
						$result = array_merge($result, $this->list_dir($dir.$file.'/'));
					}
					else{
						array_push($result, $dir.$file);
					}
				}
			}
			return $result;
		}
		
		//模板文件列表
		private function templatelist(){
			$src=PROJECT_PATH.'home/views/'.$this->templatestyle().'/';
			$cc=$this->list_dir($src);
			$html='<ul class="viewmess">';
			$html.='<li class="dark-row">';
			$html.='<span class="list_width width_font" style="width:30px;">编号</span>';
			$html.='<span class="list_width width_font" style="width:360px;">模板文件</span>';
			$html.='<span class="list_width width_font">操&nbsp;&nbsp;作</span>';
			$html.='</li>';
			for($i=0;$i<count($cc);$i++){
				$filename = array_pop(explode(".",basename($cc[$i])));
				if($filename == 'html'){
					$str = explode("/",$cc[$i]);
					$n = count($str);
					$html.='<li>';
					$html.='<form action='.B_URL.'/template method="post">';
					$html.='<input type="hidden" name="path" value='.$cc[$i].'>';
					$html.='<span class="list_width" style="width:30px;text-align:center;">'.$i.'</span>';
					$html.='<span class="list_width width_font" style="width:350px" title="物理路径“'.$cc[$i].'”">/'.$str[$n-2].'/'.$str[$n-1].'</span>';
					$html.='<span class="list_width"><input class="text-box" style="background-color:#fff;" type="submit" value="编辑模板"/></span>';
					$html.='</form>';
					$html.='</li>';
				}
			}
			$html.='<li>&nbsp;&nbsp;编号说明：0-文章内容页；1-文章列表页；3-企业介绍单页；4-留言页；5-首页；6-招聘页；7-公告详情页；8-展示列表页；9-展示详情页；10-图集列表页；11-页脚；12-页头；13-消息提示页</li>';
			$html.='</ul>';
			$this->assign('templatelist',$html);
		}
		
		//获取前端模板风格
		private function templatestyle(){
			$content=file_get_contents(PROJECT_PATH."index.php");
			$style="/define\(\"TPLSTYLE\"\s*,\s*\"(.+?)\"\);/i";
			preg_match($style,$content, $arr);
			return $arr[1];		
		}
	}