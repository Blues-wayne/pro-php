<?php
	class Acolumn{
		//栏目列表
		function index(){
			$acolumn = D('acolumn');
			$this->mess('提示：可以通过重新排序改变栏目的显示顺序,数值小的排在前面，还可以关闭部分栏目的显示.<br>注意：只能删除空栏目，如果样目下有单页或子栏目，请先删除.');
			$this->assign("list",$acolumn->parsetree());
			$this->display();
		}
		//添加栏目
		function add(){
			$acolumn = D('acolumn');
			$this->mess('带 <span class="red_font"> * </span> 为必填项<br/>未审核的单页栏目不在单页页面显示');
			$this->assign("select",$acolumn->formselect());
			$this->display();
		}
		//插入操作
		function insert(){
			$acolumn = D('acolumn');
			if($_POST["pid"] == "0"){
				$_POST['path'] = "0";
			}else{
				$data = $acolumn->field("path")->find($_POST["pid"]);
				$_POST['path'] = $data["path"]."-".$_POST["pid"];
			}
			if($acolumn->insert($_POST,1,1)){
				$this->mess("新分类【{$_POST["title"]}】添加成功",true);
			}else{
				$this->mess($acolumn->getMsg(),false);
				$this->assign("post",$_POST);
			}
			if(isset($_POST["jz"])){
				$this->assign("select",$acolumn->formselect("pid",$_POST["pid"]));
				$this->assign("jz","checked");
			}else{
				$this->assign("select",$acolumn->formselect());
			}
			$this->display("add");
		}
		//修改界面
		function mod(){
			$this->mess('提示: 带<span class="red_font"> * </span>的项目为必填信息。<br>注意：不能将类别移动到自己的子类中去. ');
			$acolumn = D("acolumn");
			$data = $acolumn->find($_GET["id"]);
			$image=D("image")->field("name")->find($data["picid"]);
			$data["picname"]=$image["name"];
			$this->assign("select",$acolumn->formselect("pid",$data["pid"]));
			$this->assign("post",$data);
			$this->display();
		}
		//修改操作
		function update(){
			$acolumn = D("acolumn");
			if($acolumn->catMod($_POST)){
				$this->mess("分类修改成功",true);
				$this->assign("list",$acolumn->parsetree());
				$this->display("index");
			}else{
				$this->mess($acolumn->getMsg(),false);
				$this->assign("select",$acolumn->formselect("pid",$_POST["pid"]));
				$this->assign("post",$_POST);
				$this->display("mod");
			}
		}
		//删除分类
		function del(){
			$acolumn = D('acolumn');
			$about=D("about");
			if($acolumn->total(array("pid"=>$_GET["id"])) > 0){
				$this->mess("请先删除当前分类下的子分类",false);
			}else if($about->total(array("pid"=>$_GET["id"])) > 0){
				$this->mess("分类中有单页存在不能删除，请先删除本类中的单页！", false);				
			}else{
				if($acolumn->delete($_GET["id"]))
					$this->mess("分类删除成功",true);
				else
					$this->mess("分类删除失败",false);
			}
			$this->assign("list",$acolumn->parsetree());
			$this->display("index");			
		}
		//排序操作
		function ord(){
			$acolumn = D('acolumn');
			$affected_rows = 0;
			for($i=0;$i<count($_POST['id']);$i++){
				$affected_rows += $acolumn->update(array("id"=>$_POST['id'][$i],"ord"=>$_POST['ord'][$i]));
			}
			if($affected_rows > 0){
				$this->mess('栏目顺序修改成功',true);
			}else{
				$this->mess('未作顺序调整',false);
			}
			$this->assign("list",$acolumn->parsetree());
			$this->display("index");
		}
		function dis(){
			$data["id"]=$_GET["id"];
			$data["display"]=$_GET["con"];
			D("acolumn")->update($data);
		}
		function tw(){
			$data["id"]=$_GET["id"];
			$data["type"]=$_GET["con"];
			D("acolumn")->update($data);
		}	
		function link(){
			$data["id"]=$_GET["id"];
			$data["link"]=$_GET["con"];
			D("acolumn")->update($data);
		}		
	}