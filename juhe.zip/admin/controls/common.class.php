<?php
	class Common extends Action {
		function init(){
			if(!(isset($_SESSION["isLogin"]) && $_SESSION["isLogin"]===1)){
				$this->redirect("login/index");
			}
			$baseadmin=array('base','flink', 'banner','notice','board');
			if(in_array($_GET["m"], $baseadmin) && $_SESSION["baseadmin"]!=1){
				$this->error("权限不足，您不能编辑基本管理频道", 3, "index/index");
			}
			$unitadmin=array('acolumn', 'about');
			if(in_array($_GET["m"], $unitadmin) && $_SESSION["unitadmin"]!=1){
				$this->error("权限不足，您不能编辑单页管理频道", 3, "index/index");
			}
			$artadmin=array('article','play','column');
			if(in_array($_GET["m"], $artadmin) && $_SESSION["artadmin"]!=1){
				$this->error("权限不足，您不能编辑文章管理频道", 3, "index/index");
			}
			$disadmin=array('photo','phcolumn');
			if(in_array($_GET["m"], $disadmin) && $_SESSION["disadmin"]!=1){
				$this->error("权限不足，你不能对展示进行操作", 3, "index/index");
			}	
			$downadmin=array('download');
			if(in_array($_GET["m"], $downadmin) && $_SESSION["downadmin"]!=1){
				$this->error("权限不足，您不能编辑下载管理频道", 3, "index/index");
			}
			$videoadmin=array('vcolumn','video');
			if(in_array($_GET["m"], $videoadmin) && $_SESSION["videoadmin"]!=1){
				$this->error("权限不足，您不能编辑视频管理频道", 3, "index/index");
			}			
			$funadmin=array('fun','advert');
			if(in_array($_GET["m"], $funadmin) && $_SESSION["funadmin"]!=1){
				$this->error("权限不足，您不能编辑碎片管理频道", 3, "index/index");
			}
			$imgadmin=array('album','image');
			if(in_array($_GET["m"], $imgadmin) && $_SESSION["imgadmin"]!=1){
				$this->error("权限不足，您不能编辑碎片管理频道", 3, "index/index");
			}	
			$dataadmin=array('databak','webbak','style','template');
			if(in_array($_GET["m"], $dataadmin) && $_SESSION["dataadmin"]!=1){
				$this->error("权限不足，您不能编辑模板数据管理频道", 3, "index/index");
			}	
			$updateadmin=array('upgrade');
			if(in_array($_GET["m"], $updateadmin) && $_SESSION["updateadmin"]!=1){
				$this->error("权限不足，您不能编辑维护管理频道", 3, "index/index");
			}
			$useradmin=array('group','user');
			if(in_array($_GET["m"], $useradmin) && $_SESSION["useradmin"]!=1){
				$this->error("权限不足，您不能编辑用户管理频道", 3, "index/index");
			}			
		}
		//消息提示及判定
		function mess($mess="ok",$is=null){
			$message = "";
			if(is_array($mess)){
				foreach($mess as $m){
					$message .= $m;
				}
			}else{
				$message = $mess;
			}
			if(is_null($is)){
				$this->assign("mess","");
			}else if($is){
				$this->assign("mess","ok");
			}else{
				$this->assign("mess","error");
			}
			$this->assign("tmess",$message);
		}
		//处理CK图片上传方法
		protected function upimage(){
			$path=PROJECT_PATH.'public/uploads';//图片上传路径
			global $pictureSize;
			$up=new FileUpload($path.'/tmp');//图片上传临时路径
			$up->set("allowtype", array("gif", "png", "jpg", "jpeg"))//允许上传类型
			   ->set("thumb", array("width"=>$pictureSize["maxWidth"], "height"=>$pictureSize["maxHeight"]))//限制尺寸
			   ->set("watermark", array("water"=>$path.'/'.WATER, "position"=>POSITION));//设置图片水印
			if($up->upload("upload")){
				$filename=$up->getFileName();//如果图片上传成功返回图片名称
				$_SESSION["article"][]=$filename;//多个图片存入SESSION一维数组
				$this->mkhtml(B_PUBLIC."/uploads/tmp/".$filename);//将路径返回CK路径框
			}else{
				$mess=strip_tags($up->getErrorMsg());//上传失败返回错误信息
				$this->mkhtml('', $mess);//弹出错误信息
			}
		}
		
		//处理CKflash上传方法
		protected function upflash(){
			$up=new FileUpload(PROJECT_PATH.'public/uploads/tmp');
			$up->set("allowtype", array("flv","swf"));
			if($up->upload("upload")){
				$filename=$up->getFileName();
				$_SESSION["article"][]=$filename;
				$this->mkhtml(B_PUBLIC."/uploads/tmp/".$filename);
			}else{
				$mess=strip_tags($up->getErrorMsg());	
				$this->mkhtml('', $mess);
			}
		}
		protected function mkhtml($fileurl,$message="") {
			$str='<script type="text/javascript">window.parent.CKEDITOR.tools.callFunction('.$_GET['CKEditorFuncNum'].', \''.$fileurl.'\', \''.$message.'\');</script>';
			exit($str);
		}
		
		//图片上传
		protected function upimg($dir,$w,$h){
			$path=PROJECT_PATH.'public/uploads/'.$dir;
			$up = new FileUpload($path);
			$up->set("thumb",array('width'=>$w,'height'=>$h));
			if($up->upload("pic")){
				$filename = $up->getFilename();
				return array(true,$filename);
			}else{
				return array(false,$up->getErrorMsg());
			}
		}	
		protected function delpic($filename,$dir){
			$file = PROJECT_PATH.'public/uploads/'.$dir.'/'.$filename;
			if(file_exists($file)){
				unlink($file);
			}
		}		
		
		protected function proRandName() {		
			$fileName=date('YmdHis').rand(100,999);   //获取随机文件名	
			return $fileName;    //返回文件名加原扩展名
		}
	}