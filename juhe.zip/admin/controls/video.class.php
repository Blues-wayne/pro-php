<?php
	class Video{
		function index(){
			$video = D("video");
			if($_GET["audit"]=="on"){
				$where["audit"] = 1;
				$pget = "/audit/on";
			}
			if($_GET["audit"]=="off"){
				$where["audit"] = 0;
				$pget = "/audit/off";				
			}
			if(!empty($_GET["pid"])){
				$where["pid"] = $_GET["pid"];
				$pget .= "/pid/{$_GET["pid"]}";
				$pid = $_GET["pid"];
			}else{
				$pid = 0;
			}
			if(!empty($_GET["search"])){
				$where["title"] = "%{$_GET["search"]}%";
				$pget .= "/search/".$_GET["search"];
				$this->assign("search",$_GET["search"]);
			}
			$this->assign('list',D('vcolumn')->formselect('pid',$pid));
			$page = new Page($video->total($where),ARTICLE_PAGE_SIZE,$pget);
			if(isset($_GET["mess"])){
				if($_GET["stats"]=="1")
					$this->mess(base64_decode($_GET["mess"]).'成功',true);
				else
					$this->mess(base64_decode($_GET["mess"]).'失败',false);
			}else{
				$this->mess("只有审核后的视频才能发布. <br>推荐后的视频将出现在首页中出现");
			}
			$arts = $video->field('id,uid,pid,title,ptime,recommend,top,audit')
							->where($where)
							->order('id desc')
							->limit($page->limit)
							->r_select(array('user','username as author','id','uid'));
			$this->assign("arts",$arts);
			$this->assign("fpage",$page->fpage());
			$this->assign("page",$page->page);
			$this->display();
		}
		
		function add(){
			$this->mess("提示：带 <span class='red_font'>*</span> 号为必填项并注意格式正确！");
			$this->assign('select',D('vcolumn')->formselect());
			$this->display();		
		}
		
		function insert(){
			$video = D('video');
			if($_POST["pid"]=="")
				$_POST["pid"]="";
			$_POST["uid"]=$_SESSION['admin']['id'];//用户编号
			$_POST["ptime"] = time();
			$up = $this->upimg('video',250,150);
			$vcolumn = D("vcolumn")->field("audit")->find($_POST["pid"]);
			if($vcolumn["audit"]==0){
				$_POST["audit"] = 1;
			}
			if($up[0]){
				$_POST["pic"] = $up[1];
				if($video->insert($_POST,1,1)){
					$this->mess('视频添加成功',true);
				}else{
					if($up[0])
						$video->delpic($up[1],'video');
					$this->assign('vcolumn',D('vcolumn')->field('id,title')->select());
					$this->assign('post',$_POST);
					$this->mess($video->getMsg(),false);
				}
			}else{
				$this->mess($up[1],false);
				$this->assign('select',D('vcolumn')->formselect());
				$this->assign('post',$_POST);
				
			}
			if(isset($_POST["jz"])){
				$this->assign('select',D('vcolumn')->formselect('pid',$_POST['pid']));
				$this->assign("jz","checked");
			}else{
				$this->assign('select',D('vcolumn')->formselect());
			}			
			$this->display("add");
		}
		
		function mod(){
			if(isset($_GET["mess"]))
				$this->mess(base64_decode($_GET["mess"]), false);
			else
				$this->mess('提示: 带<span class="red_font">*</span>的项目为必填信息.<br>不更换缩略图片时请不要点击“更换图片”按钮！ ');
			$video = D("video");
			$post = $video->find($_GET["id"]);
			$this->assign('list',D('vcolumn')->formselect('pid',$post['pid']));
			$this->assign("post",$post);
			$this->display();
		}
		
		function update(){
			$video = D("video");
			$pget = "/page/{$_GET["page"]}";
			if(!empty($_GET["search"]))
				$pget .= "/search/{$_GET["search"]}";
			if(!empty($_GET["pid"]))
				$pget .= "/pid/{$_GET["pid"]}";
			if(!empty($_GET["audit"]))
				$pget .= "/audit/{$_GET["audit"]}";
			
			if(!empty($_FILES["pic"])){
				$up = $this->upimg('video',250,150);
				if($up[0]){
					$this->delpic($_POST['dpic'],'video');//删除视频对应图片
					$_POST["pic"] = $up[1];
				}else{
					$mess = '提示：您没有选择缩略图片或缩略图片上传失败';
					$this->redirect("mod", "mess/".base64_encode($mess)."/id/{$_POST["id"]}");
				}
			}
			
   			if($video->update($_POST,1,1)){
				$mess = "视频修改";
				$this->redirect("index","stats/1/pid/{$_POST["pid"]}/mess/".base64_encode($mess).$pget);
			}else{
				$mess = $video->getMsg();
				if($mess=="")
					$mess="提示：您没有对视频做出任何修改！";
				$this->redirect("mod", "mess/".base64_encode($mess)."/id/{$_POST["id"]}");
			} 
		}
		
		function del(){
			$video = D("video");
			$pic = $video->field('id,pic')->find($_GET['id']);
			$pget = "/page/{$_GET["page"]}";
			if(!empty($_GET["search"]))
				$pget .= "/search/{$_GET["search"]}";
			if(!empty($_GET["pid"]))
				$pget .= "/pid/{$_GET["pid"]}";
			if(!empty($_GET["audit"]))
				$pget .= "/audit/{$_GET["audit"]}";
			$this->delpic($pic['pic'],'video');//删除视频对应图片	
			$result = $video->delete($_GET["id"]);
			if($result){
				$this->redirect('index','mess/'.base64_encode('视频删除').'/stats/1'.$pget);
			}else{
				$this->redirect('index','mess/'.base64_encode('视频删除').'/stats/0'.$pget);
			}	
		}

		//评论、审核的AJAX操作
		function status(){
			debug();
			$video = D("video");
			//接收由AJAX传递的参数及值
			$update = array("id"=>$_GET["id"],$_GET["s"]=>$_GET["val"]);
			if($video->update($update)){
				echo "1";
			}else{
				echo "no";
			}
		}
		
		function fpro(){
			$video = D("video");
			if(isset($_POST["allows_x"]) && isset($_POST["allows_y"])){
				$result = $video->where($_POST["id"])->update("recommend='1'");
				$mess = "批量设置推荐";
			}else if(isset($_POST["nallows_x"]) && isset($_POST["nallows_y"])){
				$result = $video->where($_POST["id"])->update("recommend='0'");
				$mess = "批量设置取消推荐";
			}else if(isset($_POST["audits_x"]) && isset($_POST["audits_y"])){
				$result = $video->where($_POST["id"])->update("audit='1'");
				$mess = "批量审核";				
			}else if(isset($_POST["locks_x"]) && isset($_POST["locks_y"])){
				$result = $video->where($_POST["id"])->update("audit='0'");
				$mess = "批量锁定";					
			}else if(isset($_POST["dels_x"]) && isset($_POST["dels_y"])){
				foreach($_POST["id"] as $id){
					$pic = $video->field('id,pic')->find($id);
					$this->delpic($pic['pic'],'video');
				}
				$result = $video->delete($_POST["id"]);
				$mess = "批量删除";
			}
 			$pget = "/page/{$_GET["page"]}";
			if(!empty($_GET["search"]))
				$pget .= "/search/{$_GET["search"]}";
			if(!empty($_GET["pid"]))
				$pget .= "/pid/{$_GET["pid"]}";
			if(!empty($_GET["audit"]))
				$pget .= "/audit/{$_GET["audit"]}";
			if($result){
				$this->redirect('index','mess/'.base64_encode($mess).'/stats/1'.$pget);
			}else{
				$this->redirect('index','mess/'.base64_encode($mess).'/stats/0'.$pget);
			} 
		}
	}