<?php
	class Article{
		function index(){
			$article = D("article");
			if($_GET["audit"]=="on"){
				$where["audit"] = 1;
				$pget = "/audit/on";
			}
			if($_GET["audit"]=="off"){
				$where["audit"] = 0;
				$pget = "/audit/off";				
			}
			if(!empty($_GET["pid"])){
				$where["pid"] = $_GET["pid"];
				$pget .= "/pid/{$_GET["pid"]}";
				$pid = $_GET["pid"];
			}else{
				$pid = 0;
			}
			$seakey = checkstr($_GET["search"]);
			if(!empty($seakey)){
				$where["title"] = "%{$seakey}%";
				$pget .= "/search/".$seakey;
				$this->assign("search",$seakey);
			}
			$this->assign("select",D("column")->formselect("pid",$pid));
			$page = new Page($article->total($where),ARTICLE_PAGE_SIZE,$pget);
			if(isset($_GET["mess"])){
				if($_GET["stats"]=="1")
					$this->mess(base64_decode($_GET["mess"]).'成功',true);
				else
					$this->mess(base64_decode($_GET["mess"]).'失败',false);
			}else{
				$this->mess("部分类别中的文章在添加后都处于锁定状态,只有审核后的文章才能发布.<br>审核后的文章也可以锁定,锁定的文章不被发布. ");
			}
			$arts = $article->field('id,title,posttime,uid,pid,audit,allow')
							->where($where)
							->order('id desc')
							->limit($page->limit)
							->r_select(array('user','username as author','id','uid'));
			$this->assign("arts",$arts);
			$this->assign("fpage",$page->fpage());
			$this->assign("page",$page->page);
			$this->display();
		}
		
		function add(){
 			$column = D("column");
			$this->assign("select",$column->formselect());
			$this->mess('提示：带<font class="red_font">*</font>的项目为必填信息.');
			$this->assign("ck",Form::editor("content","full",300,"#FAFAFA"));
			$this->assign("eck",Form::editor("econtent","full",300,"#FAFAFA"));
			$this->assign("post", array("recommend"=>0, "allow"=>1)); 
			$this->display();
		}
		
		function insert(){
			global $thumbSize;
			if(!empty($_FILES["pic"]['name'])){
				$up = $this->upimg('phoimg',$thumbSize['width'],$thumbSize['height']);	
				if($up[0]){
					$_POST["pic"] = $up[1];
				}
			}
			$article = D("article");
			if($_POST["pid"]=="0")
				$_POST["pid"]="";
			$_POST["posttime"] = time();
			$_POST["uid"] = "1";
			$content = $_POST["content"];
			$econtent = $_POST["econtent"];
			unset($_POST["content"]);
			unset($_POST["econtent"]);
			$column = D("column")->field("audit")->find($_POST["pid"]);
			if($column["audit"]==0){
				$_POST["audit"]=1;
			}
			$lastid = $article->insert($_POST,1,1);
			if($lastid && $article->aimage($content,$lastid) && $article->con($econtent,$lastid)){
				$this->mess("文章<b>{$_POST["title"]}</b>添加成功，可以继续添加",true);
				$this->assign("post",array("recommend"=>$_POST['recommend'],"allow"=>$_POST['allow']));
			}else{
				$_POST["content"]=stripslashes($content);
				$_POST["econtent"]=stripslashes($econtent);
				$this->assign("post",$_POST);
				$this->mess($article->getMsg(),false);
				$article->delete(array('id'=>$lastid));
			}
			if(isset($_POST["jz"])){
				$this->assign("select",D("column")->formselect("pid",$_POST["pid"]));
				$this->assign("jz","checked");
			}else{
				$this->assign("select",D("column")->formselect());
			}
			$this->assign("ck",Form::editor("content","full",300,"#FAFAFA"));
			$this->assign("eck",Form::editor("econtent","full",300,"#FAFAFA"));
			$this->display("add");			
		}
		
		function mod(){
			if(isset($_GET["mess"]))
				$this->mess(base64_decode($_GET["mess"]), false);
			else
				$this->mess('提示: 带<span class="red_font">*</span>的项目为必填信息.');
			$column = D("column");
			$article = D("article");
			$post = $article->find($_GET["id"]);
			$this->assign("select",$column->formselect("pid",$post["pid"]));
			$this->assign("ck",Form::editor("content","full",300,"#FAFAFA"));
			$this->assign("eck",Form::editor("econtent","full",300,"#FAFAFA"));
			$this->assign("post",$post);
			$this->display();
		}
		
		function update(){
			global $thumbSize;	
			$article = D("article");
			$artpic = $article->field("pic")->find($_POST["id"]);
			if(!empty($_FILES["pic"])){
				$up = $this->upimg('phoimg',$thumbSize['width'],$thumbSize['height']);	
				if($up[0]){
					$_POST["pic"] = $up[1];
					$this->delpic($artpic['pic'],'phoimg');
				}else{
					$mess = '提示：缩略图片上传失败';
					$this->redirect("mod", "mess/".base64_encode($mess)."/id/{$_POST["id"]}");
				}
			}
			if($_POST["pid"]=="0")
				$_POST["pid"]="";
			$content = $_POST["content"];
			$econtent = $_POST["econtent"];
			unset($_POST["content"]);
			unset($_POST["econtent"]);
			$affected = $article->update($_POST,1,1);
			$affected1 = $article->aimage($content,$_POST["id"]);
			$affected2 = $article->con($econtent,$_POST["id"]);
			$affected_rows = $affected+$affected1+$affected2;
			if($affected_rows){
				$mess = "文章修改";
				$this->redirect("index","pid/{$_POST["pid"]}/mess/".base64_encode($mess)."/stats/1");
			}else{
				$_POST["content"] = stripcslashes($content);
				$_POST["econtent"] = stripcslashes($econtent);
				$this->assign("post",$_POST);
				$mess = $article->getMsg();
				if($mess=="")
					$mess="未做任何修改";
				$this->mess($mess,false);
				$this->assign("select",D("column")->formselect("pid",$_POST["pid"]));
				$this->assign("ck",Form::editor("content","full",300,"#FAFAFA"));
				$this->assign("eck",Form::editor("econtent","full",300,"#FAFAFA"));
				$this->display("mod");
			}
		}
		
		function del(){
			$article = D("article");
			$data = $article->field('pic')->find($_GET["id"]);
			$result = $article->where($_GET["id"])->delete();
			$pget = "/page/{$_GET["page"]}";
			if(!empty($_GET["search"]))
				$pget .= "/search/{$_GET["search"]}";
			if(!empty($_GET["pid"]))
				$pget .= "/pid/{$_GET["pid"]}";
			if(!empty($_GET["audit"]))
				$pget .= "/audit/{$_GET["audit"]}";
			if($result){
				$article->delres($_GET["id"]);//删除文章对应图片
				$this->delpic($data['pic'],"phoimg");
				$this->redirect('index','mess/'.base64_encode('文章删除').'/stats/1'.$pget);
			}else{
				$this->redirect('index','mess/'.base64_encode('文章删除').'/stats/0'.$pget);
			}
		}
		//评论、审核的AJAX操作
		function status(){
			debug();
			$article = D("article");
			//接收由AJAX传递的参数及值
			$update = array("id"=>$_GET["id"],$_GET["s"]=>$_GET["val"]);
			if($article->update($update)){
				echo "1";
			}else{
				echo "no";
			}
		}
		function fpro(){
			$article = D("article");
			if(isset($_POST["allows_x"]) && isset($_POST["allows_y"])){
				$result = $article->where($_POST["id"])->update("allow='1'");
				$mess = "批量设置允许评论";
			}else if(isset($_POST["nallows_x"]) && isset($_POST["nallows_y"])){
				$result = $article->where($_POST["id"])->update("allow='0'");
				$mess = "批量设置禁止评论";
			}else if(isset($_POST["audits_x"]) && isset($_POST["audits_y"])){
				$result = $article->where($_POST["id"])->update("audit='1'");
				$mess = "批量审核";				
			}else if(isset($_POST["locks_x"]) && isset($_POST["locks_y"])){
				$result = $article->where($_POST["id"])->update("audit='0'");
				$mess = "批量锁定";					
			}else if(isset($_POST["dels_x"]) && isset($_POST["dels_y"])){
				$data = $article->field('pic')->where(array('id'=>$_POST["id"]))->select();
				$result = $article->delete($_POST["id"]);
				foreach($_POST["id"] as $id){
					$article->delres($id);
					foreach($data as $v){
						$this->delpic($v['pic'],"phoimg");
					}
				}
				$mess = "批量删除";
			}
			$pget = "/page/{$_GET["page"]}";
			if(!empty($_GET["search"]))
				$pget .= "/search/{$_GET["search"]}";
			if(!empty($_GET["pid"]))
				$pget .= "/pid/{$_GET["pid"]}";
			if(!empty($_GET["audit"]))
				$pget .= "/audit/{$_GET["audit"]}";
			if($result){
				$this->redirect('index','mess/'.base64_encode($mess).'/stats/1'.$pget);
			}else{
				$this->redirect('index','mess/'.base64_encode($mess).'/stats/0'.$pget);
			}
		}
	}