<?php 
	class Download {
		function index(){
			$download = D("download");
			if(isset($_GET["mess"])){
				if($_GET["stats"]=="1")
					$this->mess(base64_decode($_GET["mess"]),true);
				else
					$this->mess(base64_decode($_GET["mess"]),false);
			}else{
				$this->mess("共有 {$download->total()} 个下载文件.");
			}
			$page = new Page($download->total(),PHTURE_PAGE_SIZE);
			$arts = $download->field('id,title,posttime,views')->limit($page->limit)->select();
			$this->assign("arts",$arts);
			$this->assign("fpage",$page->fpage());
			$this->assign("page",$page->page);				
			$this->display();
		}

		function add(){
			$this->mess('带<span class="red_font"> * </span>号的为必填项，仅支持rar及zip文件，文件必须小于10M.');
			$this->display();
		}
		
		function insert(){
			$download = D("download");
			$up = $this->upfile();
			if($up[0]){
				$_POST["filename"] = $up[1];
				$_POST["posttime"] = time();
				if($download->insert($_POST,1,1)){
					$mess = "文件【{$_POST["title"]}】添加成功，您可以继续添加！";
					$this->mess($mess,true);
				}else{
					$this->delfile($up[1]);
					$this->mess($download->getMsg(),false);
					$this->assign("post",$_POST);
				}
			}else{
				$this->mess($up[1],false);
				$this->assign("post",$_POST);
			}
			$this->display("add");
		}
		
		function mod(){
			$this->mess('带<span class="red_font"> * </span>号的为必填项');
			$download = D("download");
			$data = $download->find($_GET["id"]);
			$image=D("image")->field("name")->find($data["picid"]);
			$data["picname"]=$image["name"];
			$this->assign("post",$data);
			$this->display();
		}
		
		function update(){
			$download = D("download");
			if($download->update($_POST,1,1)){
				$mess="修改成功";
				$this->redirect("index","stats/1/mess/".base64_encode($mess));
			}else{				
				$mess = $download->getMsg();
 				if($mess=="")
					$mess="您未出任何修改"; 
				$this->mess($mess,false);
				$this->assign("post",$_POST);
				$this->display("mod");	
			}			
		}
		
		function del(){
			$download = D("download");
			$data = $download->field('filename')->find($_GET["id"]);
			$result = $download->delete($_GET["id"]);
			$pget = "/page/{$_GET["page"]}";
			if($result){
				$this->delfile($data['filename']);
				$this->redirect('index','mess/'.base64_encode('文件成功删除').'/stats/1'.$pget);
			}else{
				$this->redirect('index','mess/'.base64_encode('文件删除失败').'/stats/0'.$pget);
			}
		}
		
		private function upfile(){
			$path=PROJECT_PATH.'public/uploads/down';
			$up = new FileUpload($path);
			$up->set('maxSize',9000000)->set('allowType',array('rar','zip'));
			if($up->upload("file")){
				$filename = $up->getFilename();
				return array(true,$filename);
			}else{
				return array(false,$up->getErrorMsg());
			}
		}
		
		private function delfile($filename){
			$file = PROJECT_PATH.'public/uploads/down/'.$filename;
			if(file_exists($file)){
				unlink($file);
			}
		}
	}
