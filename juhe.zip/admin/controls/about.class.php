<?php
	class About{
		function index(){
			$about = D("about");
			if(!empty($_GET["pid"])){
				$where=array('pid'=>$_GET["pid"]);
				$pid = $_GET["pid"];
				$pget .= "/pid/{$_GET["pid"]}";
			}else{
				$pid = 0;
			}
			if(isset($_GET["mess"])){
				if($_GET["stats"]==1)
					$this->mess(base64_decode($_GET["mess"]).'成功',true);
				else
					$this->mess(base64_decode($_GET["mess"]).'失败',false);
			}else{
				$this->mess("共有 <span class='red_font'>{$about->total()}</span> 个单页项.<br/>如果某个分类下有多个单页项，可在分类管理中将其设为“多图文”");			
			}
			$page = new Page($about->total($where),ARTICLE_PAGE_SIZE,$pget);
			$this->assign('select',D('acolumn')->formselect("pid",$pid));
			$this->assign("arts",$about->field('id,pid,title,audit,ord')->order('ord,id desc')->limit($page->limit)->select($where));
			$this->assign("fpage",$page->fpage(0,1,2,3,4,5,6));
			$this->assign("page",$page->page);
			$this->display();
		}
		
		function add(){
			$this->mess('带 <span class="red_font">*</span> 号的为必填项');
			$this->assign('select',D('acolumn')->formselect());
			$this->assign("ck",Form::editor("content","full",200,"#FAFAFA"));
			$this->assign("eck",Form::editor("econtent","full",200,"#FAFAFA"));
			$this->display();
		}
		
		function insert(){
			$about = D("about");
			$content = $_POST["content"];
			$econtent = $_POST["econtent"];
			$up = $this->upimg('phoimg',800,600);
			if($up[0]){
				if($_POST["pid"]=="0")
					$_POST["pid"]="";
				$_POST["pic"] = $up[1];				
				unset($_POST["content"]);
				unset($_POST["econtent"]);
				$lastid = $about->insert($_POST,1,1);
				if($lastid && $about->aimage($content,$lastid,"us_") && $about->con($econtent,$lastid,"us_")){
					$this->mess("单页【<b>{$_POST["title"]}</b>】添加成功，可以继续添加",true);
				}else{
					$_POST["content"]=stripslashes($content);
					$_POST["econtent"]=stripslashes($econtent);
					$this->assign("post",$_POST);
					$this->mess($about->getMsg(),false);
					$about->delete(array('id'=>$lastid));
				}				
			}else{
				$this->assign("post",$_POST);
				$this->mess($up[1],false);			
			}

			$this->assign("ck",Form::editor("content","full",200,"#FAFAFA"));
			$this->assign("eck",Form::editor("econtent","full",200,"#FAFAFA"));
			if(isset($_POST["jz"])){
				$this->assign("select",D('acolumn')->formselect("pid",$_POST["pid"]));
				$this->assign("jz","checked");
			}else{
				$this->assign("select",D('acolumn')->formselect());
			}	
			$this->display("add");			
		}
		
		function mod(){
			$this->mess('带 <span class="red_font">*</span> 号的为必填项');
			$about = D("about");
			$post=$about->find($_GET["id"]);
			$this->assign("select",D('acolumn')->formselect("pid",$post["pid"]));			
			$this->assign("ck",Form::editor("content","full",200,"#FAFAFA"));
			$this->assign("eck",Form::editor("econtent","full",200,"#FAFAFA"));
			$this->assign("post",$post);
			$this->display();
		}
		
		function update(){
			$about = D("about");
			$phpic = $about->field("pic")->find($_POST["id"]);
			if(!empty($_FILES["pic"])){
				$up = $this->upimg('phoimg',800,600);
				if($up[0]){
					$_POST["pic"] = $up[1];
					$this->delpic($phpic['pic'],'phoimg');
				}else{
					$mess = '提示：您没有选择缩略图片或缩略图片上传失败';
					$this->redirect("mod", "mess/".base64_encode($mess)."/id/{$_POST["id"]}");
				}
			}
			if($_POST["pid"]=="0")
				$_POST["pid"]="";
			$content = $_POST['content'];
			$econtent = $_POST['econtent'];
			unset($_POST['content']);
			unset($_POST['econtent']);
			$affected = $about->update($_POST,1,1);
			$affected1 = $about->aimage($content,$_POST["id"],"us_");
			$affected2 = $about->con($econtent,$_POST["id"],"us_");
			$affected_rows = $affected+$affected1+$affected2;
			if($affected_rows){
				$this->redirect('index',"stats/1/pid/{$_POST["pid"]}/mess/".base64_encode('修改'));
			}else{
				if($mess=="")
					$mess="提示：您没有做出任何修改！";
				$this->mess($mess,false);
				$_POST["content"]=stripslashes($content);
				$_POST["econtent"]=stripslashes($econtent);
				$this->assign("ck",Form::editor("content","full",300,"#FAFAFA"));
				$this->assign("eck",Form::editor("econtent","full",300,"#FAFAFA"));
				$this->assign("select",D('acolumn')->formselect("pid",$_POST["pid"]));
				$this->assign("post",$_POST);
				$this->display("mod");
			}
		}
		
		function del(){
			$about = D("about");
			$data = $about->field('pic')->find($_GET["id"]);
			$result = $about->delete($_GET["id"]);
			if($result){
				$about->delres($_GET["id"],"us_");
				$this->delpic($data['pic'],"phoimg");
				$this->redirect('index','mess/'.base64_encode('单页删除')."/stats/1/page/{$_GET["page"]}/pid/{$_GET["pid"]}");
			}else{
				$this->redirect('index','mess/'.base64_encode('单页删除')."/stats/0/page/{$_GET["page"]}/pid/{$_GET["pid"]}");
			}		
		}
		
		function order(){
			$about = D("about");
			for($i=0;$i<count($_POST["ids"]);$i++){
				$about->update(array("id"=>$_POST["ids"][$i],"ord"=>$_POST["ord"][$i]));
			}
			$this->redirect("index",'mess/'.base64_encode('单页排序')."/stats/1/pid/{$_GET["pid"]}");
		}
		
		function status(){
			debug();
			$about = D("about");
			//接收由AJAX传递的参数及值
			$update = array("id"=>$_GET["id"],$_GET["s"]=>$_GET["val"]);
			if($about->update($update)){
				echo "1";
			}else{
				echo "no";
			}
		}
		
	}