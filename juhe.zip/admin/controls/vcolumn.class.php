<?php
	class Vcolumn{
		//栏目列表
		function index(){
			$vcolumn = D('vcolumn');
			$this->mess('提示：只能删除空栏目，如果栏目下有视频，请先将其删除.');
			$list = $vcolumn->field('id,title,pid,concat(path,"-",id) as abspath,ord,display,link')->order("abspath,id asc")->select();
			$this->assign('list',$list);
			$this->display();
		}
		//添加栏目
		function add(){
			$vcolumn = D('vcolumn');
			$this->mess('带 <span class="red_font"> * </span> 为必填项');
			$this->assign('select',$vcolumn->formselect());
			$this->display();
		}
		//插入操作
		function insert(){
			$vcolumn = D('vcolumn');
			if($_POST["pid"] == "0"){
				$_POST['path'] = "0";
			}else{
				$data = $vcolumn->field("path")->find($_POST["pid"]);
				$_POST['path'] = $data["path"]."-".$_POST["pid"];
			}
			if($vcolumn->insert($_POST,1,1)){
				$this->mess("新分类【{$_POST["title"]}】添加成功",true);
			}else{
				$this->mess($vcolumn->getMsg(),false);
				$this->assign("post",$_POST);
			}
			if(isset($_POST["jz"])){
				$this->assign("select",$vcolumn->formselect("pid",$_POST["pid"]));
				$this->assign("jz","checked");
			}else{
				$this->assign("select",$vcolumn->formselect());
			}
			$this->display("add");
		}
		//修改界面
		function mod(){
			$this->mess('提示: 带<span class="red_font"> * </span>的项目为必填信息。 ');
			$vcolumn = D("vcolumn");
			$data = $vcolumn->find($_GET["id"]);
			$this->assign('select',$vcolumn->formselect("pid",$data["pid"]));
			$this->assign("post",$vcolumn->find($_GET["id"]));
			$this->display();
		}
		//修改操作
		function update(){
			$vcolumn = D("vcolumn");
			if($vcolumn->catMod($_POST)){
				$this->mess("分类修改成功",true);
				$this->assign('list',$vcolumn->field('id,title,pid,concat(path,"-",id) as abspath,ord,display,link')->order("abspath,id asc")->select());
				$this->display("index");
			}else{
				$this->mess($vcolumn->getMsg(),false);
				$this->assign("select",$vcolumn->formselect("pid",$_POST["pid"]));
				$this->assign("post",$_POST);
				$this->display("mod");
			}
		}
		//删除分类
		function del(){
			$vcolumn = D('vcolumn');
			$video=D("video");
			if($vcolumn->total(array("pid"=>$_GET["id"])) > 0){
				$this->mess("请先删除当前分类下的子分类",false);
			}else if($video->total(array("pid"=>$_GET["id"])) > 0){
				$this->mess("分类中有视频存在不能删除，请先删除本类中的视频！", false);				
			}else{
				if($vcolumn->delete($_GET["id"]))
					$this->mess("分类删除成功",true);
				else
					$this->mess("分类删除失败",false);
			}
			$this->assign('list',$vcolumn->field('id,title,pid,concat(path,"-",id) as abspath,ord,display,link')->order("abspath,id asc")->select());
			$this->display("index");			
		}
		
		//排序操作
		function ord(){
			$vcolumn = D('vcolumn');
			$affected_rows = 0;
			for($i=0;$i<count($_POST['id']);$i++){
				$affected_rows += $vcolumn->update(array("id"=>$_POST['id'][$i],"ord"=>$_POST['ord'][$i]));
			}
			if($affected_rows > 0){
				$this->mess('栏目顺序修改成功',true);
			}else{
				$this->mess('未作顺序调整',false);
			}
			$this->assign('list',$vcolumn->field('id,title,pid,concat(path,"-",id) as abspath,ord,display,link')->order("abspath,id asc")->select());
			$this->display("index");
		}
		
		function status(){
			debug();
			$vcolumn = D("vcolumn");
			//接收由AJAX传递的参数及值
			$update = array("id"=>$_GET["id"],$_GET["s"]=>$_GET["val"]);
			if($vcolumn->update($update)){
				echo "1";
			}else{
				echo "no";
			}
		}
	}