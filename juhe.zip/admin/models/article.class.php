<?php
	class Article extends Ck{
	
	}