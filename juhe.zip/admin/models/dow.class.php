<?php
	class Dow extends Ck{
	
	}