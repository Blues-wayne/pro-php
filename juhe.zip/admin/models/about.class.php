<?php
	class About extends Ck{
	
	}