<?php
	class Menu extends Cat{
	}