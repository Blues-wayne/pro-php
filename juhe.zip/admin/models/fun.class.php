<?php
	class Fun extends Ck{
	
	}