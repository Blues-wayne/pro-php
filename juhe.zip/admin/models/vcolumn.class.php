<?php
	class vcolumn extends Cat{

	}