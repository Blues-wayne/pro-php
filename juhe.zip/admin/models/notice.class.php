<?php
	class Notice extends Ck{
	
	}