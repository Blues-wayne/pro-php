<?php
class Article{
	function index(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {
		$column=D("column");
		$article=D("article");
		$pid = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
		$current=$column->where(array("id"=>$pid, "display"=>1))->find();
		if(!$current){
			$this->error("该栏目不存在或已经被关闭!", 3, "index/index");
		}
		
		//广告图
		$advert = D('advert');
		$ad = $advert->where(array('display'=>1,'wz'=>3))->order('ord asc')->select();
		$this->assign('ad',$ad);
		
		//轮播图
		$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>10))->find());
		
		//文章栏目
		/***************
 		$artcol = $column->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
		$this->assign('colfive',$column->colfive($artcol,B_URL.'/index/pid/')); **/
		
		/******单独显示分类关闭上方文章栏目并开启此代码******/
		
		$cid = explode("-",$current['path']);
		$artcol = $column->field('id,title')->order("ord asc")->where(array("pid"=>1,"display"=>1))->select();
		$this->assign('col',$artcol);
		
		//当前位置
		$locs=$column->field('id,title,description')->where(str_replace('-',',', $current["path"]).','.$pid)->order('path asc')->select();
		$this->assign("locs", $locs);
		
		//新闻动态
		if($current["audit"]==1){
			$wherelist=array("pid"=>$pid, "audit"=>1);
			$twhere=array("pid"=>$pid, "audit"=>1,"allow"=>1,"recommend >"=>0);
			$rwhere=array("recommend >"=>0, "audit"=>1, "pid"=>$pid);
			$hwhere=array("audit"=>1, "pid"=>$pid);
		}else{
			$wherelist=array("pid"=>$pid);
			$twhere=array("pid"=>$pid, "audit"=>1,"allow"=>1,"recommend >"=>0);
			$rwhere=array("recommend >"=>0, "pid"=>$pid);	
			$hwhere=array("audit"=>1, "pid"=>$pid);
		}
		
		$this->assign('tart',$article->field('id,title,posttime,summary')->where($twhere)->order('id desc')->limit(3)->select());
		$this->assign('rart',$article->field('id,title,posttime')->where($rwhere)->order('id desc')->limit(6)->select());
		$this->assign('hart',$article->field('id,title,posttime')->where($hwhere)->order('views desc')->limit(6)->select());
		$page=new Page($article->where($wherelist)->total(),ARTICLE_PAGE_SIZE, "pid/{$pid}");
		$page->set("head","条");
		$this->assign("arts", $article->field('id,title,pic,posttime,summary,allow,views')->where($wherelist)->order("id desc")->limit($page->limit)->select());
		$this->assign("fpage", $page->fpage(4,5,6,0,3));			
		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
	
	function show(){	
		$article=D("article");
		$aid = filter_var($_GET["aid"],FILTER_VALIDATE_INT);
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			$column=D("column");
			$adata=$article->where(array("id"=>$aid,"audit"=>"1"))->find();//获取文章	
			$this->assign("author",D('user')->where(array("id"=>$adata["uid"]))->find());//获取文章作者
			if(!$adata){
				$this->error("你现在访问的文章不存在或没有审核!", 3, "index/index");
			}
			
			//分配文章
			$adata["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $adata["content"]);
			$this->assign("article", $adata);
			
			//广告图
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>4))->order('ord asc')->select();
			$this->assign('ad',$ad);
			
			//轮播图
			$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>10))->find());

			//将网站名称分配到模板中，在标题栏中显示
			$this->assign("appname", $adata["title"]);
			$this->assign("keywords",$adata["keyword"]);
			$this->assign("description", $adata["summary"]);	
			
			$columns=$column->where(array("id"=>$adata["pid"], "display"=>1))->find();//文章父ID
			
			//文章栏目
			/***********
			$artcol = $column->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
			$this->assign('colfive',$column->colfive($artcol,B_URL.'/index/pid/'));***************/
			
			/******单独显示分类关闭上方文章栏目并开启此代码******/
			$cid = explode("-",$columns['path']);
			$atrcol = $column->field('id,title')->order("ord asc")->where(array("pid"=>1,"display"=>1))->select();
			$this->assign('col',$atrcol);
			
			//当前位置
			$locs=$column->field('id,title,description')->where(str_replace('-',',', $columns["path"]).','.$columns["id"])->order('path asc')->select();
			$this->assign("locs", $locs);	
			
			//上一篇和下一篇	
			if($columns["audit"]==1){
				$prevwhere=array("audit"=>1, "pid"=>$adata["pid"],"id <"=>$aid);
				$nextwhere=array("audit"=>1, "pid"=>$adata["pid"],"id >"=>$aid);
				$connwhere=array("audit"=>1, "pid"=>$adata["pid"]);
				$recowhere=array("audit"=>1, "pid"=>$adata["pid"], "recommend >"=>0);
				$hotswhere=array("audit"=>1, "pid"=>$adata["pid"]);
			}else{
				$prevwhere=array("pid"=>$adata["pid"],"id <"=>$aid);
				$nextwhere=array("pid"=>$adata["pid"],"id >"=>$aid);
				$connwhere=array("pid"=>$adata["pid"]);
				$recowhere=array("pid"=>$adata["pid"], "recommend >"=>0);
				$hotswhere=array("pid"=>$adata["pid"]);
			}
			$this->assign("prevArticle",$article->field("id, title")->where($prevwhere)->order("id desc")->find());
			$this->assign("nextArticle", $article->field("id, title")->where($nextwhere)->order("id asc")->find());	
			$this->assign("cart", $article->field("id, title")->where($connwhere)->order("id asc")->select());	
			$this->assign("rart", $article->field("id, title")->where($recowhere)->order("id asc")->select());	
			$this->assign("hart", $article->field("id, title")->where($hotswhere)->order("views desc")->select());	

		}
		$this->assign('views',$article->field('id,views')->find($aid));
		$article->where(array("id"=>$aid))->update("views=views+1");
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
}