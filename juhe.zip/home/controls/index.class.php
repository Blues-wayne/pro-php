<?php
/***********************************
	控制器名称：index；
	作用模板：首页、公告页；
	方法数量：2个；
	方法名称：首页function index(){}、公告页function notice(){}；
************************************/
class Index {
	function index() {
		if(!$this->isCached()) {			
			/******广告图******/
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>1))->order('ord asc')->select();
			$this->assign('ad',$ad);			

			/******幻灯片******/
			$play=D("play")->field('id,aid,pic,title')->where('display="1" and "'.$time.'" > starttime and ("'.$time.'" < endtime or endtime="0")')->order("ord asc")->limit(6)->select();
			$this->assign("play",$play);
			
			/******视频******/
			$this->assign("video", D('video')->field('id,url')->where(array('recommend'=>1,'audit'=>1))->find());

			/******图片调用数据******/
			$phcolumn = D('phcolumn');
			$photo = D('photo');
			$this->assign("pro1",$photo->field('id,pid,title,summary,pic,posttime')->order('id desc')->limit(6)->select(array("audit"=>1,"recommend"=>1,'pid <'=>15)));//产品
			$this->assign("pro2",$photo->field('id,title,summary,pic,posttime')->order('id desc')->limit(16)->select(array("audit"=>1,"recommend"=>1,'pid'=>$phcolumn->callid2())));//案例
			$this->assign("pro3",$photo->field('id,title,summary,pic,posttime')->order('id desc')->limit(16)->select(array("audit"=>1,"recommend"=>1,'pid'=>$phcolumn->callid3())));//其它
			
			/*产品关键词*/
			$this->assign("key",$phcolumn->field('id,title')->where(array('pid'=>3),array('pid'=>2))->order('ord,id desc')->limit(10)->select());

			/******展示调用样本，
			$this->assign("自定义标签名称",$photo->field('id,title,summary,pic,posttime')->order('id desc')->limit(16)->select(array("audit"=>1,"recommend"=>1,'pid'=>$phcolumn->替换为Model中的新方法名称())));******/
			
			
			/******企业概况（碎片样本）******/
			$fun = D("fun")->where(array("id"=>2,"audit"=>1))->find();
			if($fun){
				$fun["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $fun["content"]);
				$this->assign("about",$fun["content"]);
			}else{
				$this->assign("about","管理员已取消显示");
			}

			/******文章栏目与标题******/
			$column=D("column");
			$data=$column->field("id,title,description")->where(array("pid"=>1,"callid"=>1))->order("ord asc")->limit(HOME_COLUMN_SIZE)
				->r_select(
					array("article",'id,title,summary,posttime', 'pid', array('art','id desc',HOME_COLUMNPAGE_SIZE,"audit=1 and recommend=1")),
					array("image",'name as imgname','id','picid')
					);
			$this->assign("cols",$data);
			
			/*生产车间*/
			$this->assign("image",D('image')->field('id,name,title')->where(array("pid"=>2))->select());
		}
		$this->display();
	}
	
	function notice(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			/******公告******/
			$n=D("notice");
			$time=strtotime(date("Y-m-d"))+60*60*24;
			$id = filter_var($_GET["id"],FILTER_VALIDATE_INT);
			$notice=$n->where(array("id"=>$id, "display"=>'1'))->find();
			if(!($notice and $notice["starttime"] < $time and ($notice["endtime"] > $time or $notice["endtime"]=='0'))){
				$this->error("访问公告失败", 3, "index/index");
			}
			$notice["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $notice["content"]);
			$this->assign("not", $notice);			
		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}

}