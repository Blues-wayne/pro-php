<?php
class Ject {
	function index(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {
		$phcolumn = D("phcolumn");
		$photo= D("photo");	
		$pid = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
		$current = $phcolumn->where(array("id"=>$pid,"display"=>1))->find();
		if(!$current){
			$this->error("该栏目不存在或已经被关闭!", 3, "index/index");
		}
		
		//广告图
		$advert = D('advert');
		$ad = $advert->where(array('display'=>1,'wz'=>5))->order('ord asc')->select();
		$this->assign('ad',$ad);
		
		//轮播图
		$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>8))->find());
		
		//展示栏目
		$cid = explode("-",$current['path']);
		$phcol = $phcolumn->field('id,title')->order("ord asc")->where(array("id"=>$cid[1],"display"=>1))->select();
		$this->assign('colfive',$phcolumn->colfive($phcol,B_URL.'/index/pid/'));
		
		/*显示全部分类关闭上方展示栏目并开启此代码
		$phcol = $phcolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
		$this->assign('colfive',$phcolumn->colfive($phcol,B_URL.'/index/pid/'));*/		

		//当前位置
		$locs=$phcolumn->field('id,title,description')->where(str_replace('-',',', $current["path"]).','.$pid)->order('path asc')->select();
		$this->assign("locs", $locs);
		
		if($current["audit"]==1){
			$wherelist=array("pid"=>$pid, "audit"=>1);
			$twhere=array("pid"=>$pid, "audit"=>1,'top'=>1);
			$rwhere=array("pid"=>$pid, "audit"=>1,'recommend'=>1);
			$hwhere=array("audit"=>1, "pid"=>$_GET["pid"]);
		}else{
			$wherelist=array("pid"=>$pid);
			$twhere=array("pid"=>$pid,'top'=>1);
			$rwhere=array("pid"=>$pid,'recommend'=>1);
			$hwhere=array("pid"=>$pid);
		}
		/*置顶、推荐、热门*/		
		$this->assign("tp", $photo->field('id,title,pic')->where($twhere)->order("id desc")->limit(6)->select());
		$this->assign("rp", $photo->field('id,title,pic')->where($rwhere)->order("id desc")->limit(6)->select());
		$this->assign("hp", $photo->field('id,title,pic')->where($hwhere)->order("views desc")->limit(6)->select());
		
		/*本类下的图片*/
		$page=new Page($photo->where($wherelist)->total(), 8, "pid/{$pid}");
		$page->set("head","个展示");
		$photos = $photo->field('id,title,summary,pic')->where($wherelist)->order("id asc")->limit($page->limit)->select();
		$this->assign("pros", $photos);
		$this->assign("fpage", $page->fpage(4,5,6));			
		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
	
	function show() {
		$photo= D("photo");
		$id = filter_var($_GET["id"],FILTER_VALIDATE_INT);
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			//广告图
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>6))->order('ord asc')->select();
			$this->assign('ad',$ad);
			
		//轮播图
		$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>8))->find());
			
			//获取产品
			$phcolumn = D("phcolumn");
			$pdata=$photo->where(array("id"=>$id))->find();
			if(!$pdata){
				$this->error("你现在访问的产品不存在或没有审核!", 3, "index/index");
			}
			
			/**展示栏目**/
 			$current = $phcolumn->field('id,path,audit')->where(array("id"=>$pdata['pid'],"display"=>1))->find();
			$cid = explode("-",$current['path']);
			$procol = $phcolumn->field('id,title')->order("ord asc")->where(array("id"=>$cid[1],"display"=>1))->select();
			$this->assign('colfive',$phcolumn->colfive($procol,B_URL.'/index/pid/')); 
			
			if($current["audit"]==1){
				$prevwhere=array("audit"=>1, "pid"=>$current['id'],"id <"=>$id);
				$nextwhere=array("audit"=>1, "pid"=>$current['id'],"id >"=>$id);
				$wherelist=array("pid"=>$current['id'], "audit"=>1);
				$twhere=array("pid"=>$current['id'], "audit"=>1,'top'=>1);
				$rwhere=array("pid"=>$current['id'], "audit"=>1,'recommend'=>1);
				$hwhere=array("audit"=>1, "pid"=>$current['id']);
			}else{
				$prevwhere=array("pid"=>$current["id"],"id <"=>$id);
				$nextwhere=array("pid"=>$current["id"],"id >"=>$id);
				$wherelist=array("pid"=>$current['id']);
				$twhere=array("pid"=>$current['id'],'top'=>1);
				$rwhere=array("pid"=>$current['id'],'recommend'=>1);
				$hwhere=array("pid"=>$current['id']);
			}
			/*置顶、推荐、热门*/	
			$this->assign("prevArticle",$photo->field("id, title")->where($prevwhere)->order("id desc")->find());
			$this->assign("nextArticle", $photo->field("id, title")->where($nextwhere)->order("id asc")->find());				
			$this->assign("tp", $photo->field('id,title,pic')->where($twhere)->order("id desc")->limit(6)->select());
			$this->assign("rp", $photo->field('id,title,pic')->where($rwhere)->order("id desc")->limit(6)->select());
			$this->assign("hp", $photo->field('id,title,pic')->where($hwhere)->order("views desc")->limit(6)->select());			
			
			/******显示全部分类关闭上方展示栏目并开启此代码
			$current = $phcolumn->field('id,path')->where(array("id"=>$pdata['pid'],"display"=>1))->find();
			$procol = $phcolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
			$this->assign('colfive',$phcolumn->colfive($procol,B_URL.'/index/pid/'));*****/		

			/*当前位置*/
			$locs=$phcolumn->field('id,title,description')->where(str_replace('-',',', $current["path"]).','.$current["id"])->order('path asc')->select();
			$this->assign("locs", $locs);
			
			//分配展示到模板
			$pdata["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $pdata["content"]);
			$this->assign("photo", $pdata);
		}
		$this->assign('views',$photo->field('id,views')->find($id));
		$photo->where(array("id"=>$id))->update("views=views+1");
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
}