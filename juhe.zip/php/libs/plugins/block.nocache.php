<?php
	function smarty_block_nocache($args, $content, &$smarty){
		return $content;
	}
