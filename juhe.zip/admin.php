<?php
	define("CSTART","0");         			//缓存是否开启1为开启0为关闭	
	define("TPLSTYLE","default");          //默认模板存放的目录	
	define("APP", "./admin");
	require "./php/index.php";
