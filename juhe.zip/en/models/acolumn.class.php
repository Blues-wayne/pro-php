<?php
	class Acolumn extends column{
	
	}