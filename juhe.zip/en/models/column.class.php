<?php
	class Column{
		function callid(){
			$artcol = $this->field('id,pid')->where(array("callid"=>1))->select();
 			for($i=0;$i<count($artcol);$i++){
				$where[] = $artcol[$i]['pid'];
			}
			return $where;
		}

		function colfive($topcolnum,$url){
			$col="";
			foreach($topcolnum as $row){
				$col.="<dl class='left-col-style'>";
					$col.="<dt class='left-one-col-style'>{$row['etitle']}</dt>";
					$two=$this->field('id,etitle,link')->where(array('pid'=>$row['id']))->order('ord asc')->select();
					$col.="<div class='left-col-con'>";
					foreach($two as $tworow){					
					$col.="<dt>";
						$col.="<dl>";
						if($tworow['link']==1){
							$col.="<dt class='left-two-col-style'><a href='{$url}{$tworow['id']}'>{$tworow['etitle']}</a><span class='l-two'>-</span></dt>";						
						}else{
							$col.="<dt class='left-two-col-style'><a>{$tworow['etitle']}</a><span class='l-two'>-</span></dt>";						
						}
							$three=$this->field('id,etitle,link')->order("ord asc")->where(array('pid'=>$tworow['id'],"display"=>1))->order('ord asc')->select();
							foreach($three as $threerow){							
							$col.="<dt>";
								$col.="<dl>";
								if($threerow['link']==1){
									$col.="<dt class='left-three-col-style'><a href='{$url}{$threerow['id']}'>{$threerow['etitle']}</a><span class='l-three'>-</span></dt>";								
								}else{
									$col.="<dt class='left-three-col-style'><a>{$threerow['etitle']}</a><span class='l-three'>-</span></dt>";								
								}
									$four=$this->field('id,etitle,link')->order("ord asc")->where(array('pid'=>$threerow['id'],"display"=>1))->order('ord asc')->select();
									foreach($four as $fourrow){									
									$col.="<dt>";
										$col.="<dl>";
										if($fourrow['link']==1){
											$col.="<dt class='left-four-col-style'><a href='{$url}{$fourrow['id']}'>{$fourrow['etitle']}</a><span class='l-four'>-</span></dt>";
										}else{
											$col.="<dt class='left-four-col-style'><a>|-{$fourrow['etitle']}</a><span class='l-four'>-</span></dt>";	
										}
											$five=$this->field('id,etitle,link')->order("ord asc")->where(array('pid'=>$fourrow['id'],"display"=>1))->order('ord asc')->select();
											foreach($five as $fiverow){	
											if($fiverow['link']==1){
												$col.="<dt class='left-five-col-style'><a href='{$url}{$fiverow['id']}'>|-{$fiverow['etitle']}</a></dt>";											
											}else{
												$col.="<dt class='left-five-col-style'><a>|-{$fiverow['etitle']}</a></dt>";											
											}

											}
										$col.="</dl>";
									$col.="</dt>";
									}		
								$col.="</dl>";
							$col.="</dt>";
							}				
						$col.="</dl>";
					$col.="</dt>";
					}
					$col.="</div>";
				$col.="</dl>";
			}
			return $col;
		}		
	}