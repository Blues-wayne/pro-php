<?php
	class Vcolumn extends column{
	
	}