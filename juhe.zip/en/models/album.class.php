<?php
	class Album extends column{
	
	}