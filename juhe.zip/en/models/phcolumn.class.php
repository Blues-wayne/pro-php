<?php
	class Phcolumn extends column{
	/*
	该文件为首页图片调用的MODEL，默认有3个方法，您可以根据模板设计需要调用更多的图片分类以适应首页图片展示的需求；
	您只需复制以下任意一个方法并重新为其命名即可；
	*/
		function callid(){
			$phcol = $this->field('id')->where(array("callid"=>1))->select();
 			for($i=0;$i<count($phcol);$i++){
				$where[] = $phcol[$i]['id'];
			}
			return $where;
		}
		function callid2(){
			$phcol = $this->field('id')->where(array("callid"=>2))->select();
 			for($i=0;$i<count($phcol);$i++){
				$where[] = $phcol[$i]['id'];
			}
			return $where;
		}
		function callid3(){
			$phcol = $this->field('id')->where(array("callid"=>3))->select();
 			for($i=0;$i<count($phcol);$i++){
				$where[] = $phcol[$i]['id'];
			}
			return $where;
		}
		/*示例，自定义方法名与首页控制器调用的方法名一致
		function 自定义方法名(){
			$phcol = $this->field('id')->where(array("callid"=>3))->select();
 			for($i=0;$i<count($phcol);$i++){
				$where[] = $phcol[$i]['id'];
			}
			return $where;
		}		
		*/
	}