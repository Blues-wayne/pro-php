<?php 
class Board {
	function index(){
		if(!$this->isCached()) {

		//分配单页栏目
		$id = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
		$acolumn = D('acolumn');
		$abtcol = $acolumn->field('id,title')->order("ord asc")->where(array("id"=>$id,"display"=>1))->select();
		$this->assign('colfive',$acolumn->colfive($abtcol,B_APP.'/alone/index/pid/'));		
		}
		$this->display();
	}
	
	function boardinsert(){
		$board = D('board');
		$_POST['posttime'] = time();
		if($board->insert($_POST,1,1)){
			$this->success('提交成功，我们会尽快与您联系',1,'index');
		}else{
			$this->error($board->getMsg(),3,'index/board');
		}
	}
	
	//验证码
	function code(){
		ob_clean();
		echo new Vcode(50,18);
	}
}