<?php
class Video {
	function index(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {
		$vcolumn = D("vcolumn");
		$video= D("video");	
		$pid = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
		$current = $vcolumn->where(array("id"=>$pid,"display"=>1))->find();
		if(!$current){
			$this->error("该栏目不存在或已经被关闭!", 3, "index/index");
		}
		
		//广告图
		$advert = D('advert');
		$ad = $advert->where(array('display'=>1,'wz'=>5))->order('ord asc')->select();
		$this->assign('ad',$ad);
		
		//展示栏目
		$cid = explode("-",$current['path']);
		$phcol = $vcolumn->field('id,title')->order("ord asc")->where(array("id"=>$cid[1],"display"=>1))->select();
		$this->assign('colfive',$vcolumn->colfive($phcol,B_URL.'/index/pid/'));
		
		/*显示全部分类关闭上方展示栏目并开启此代码
		$phcol = $vcolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
		$this->assign('colfive',$vcolumn->colfive($phcol,B_URL.'/index/pid/'));*/		

		//当前位置
		$locs=$vcolumn->field('id,title,description')->where(str_replace('-',',', $current["path"]).','.$pid)->order('path asc')->select();
		$this->assign("locs", $locs);
		
		if($current["audit"]==1){
			$wherelist=array("pid"=>$pid, "audit"=>1);
			$twhere=array("pid"=>$pid, "audit"=>1,'top'=>1);
			$rwhere=array("pid"=>$pid, "audit"=>1,'recommend'=>1);
			$hwhere=array("audit"=>1, "pid"=>$_GET["pid"]);
		}else{
			$wherelist=array("pid"=>$pid);
			$twhere=array("pid"=>$pid,'top'=>1);
			$rwhere=array("pid"=>$pid,'recommend'=>1);
			$hwhere=array("pid"=>$pid);
		}
		/*置顶、推荐、热门*/		
		$this->assign("tp", $video->field('id,title,pic')->where($twhere)->order("id desc")->limit(6)->select());
		$this->assign("rp", $video->field('id,title,pic')->where($rwhere)->order("id desc")->limit(6)->select());
		$this->assign("hp", $video->field('id,title,pic')->where($hwhere)->order("views desc")->limit(6)->select());
		
		/*本类下的图片*/
		$page=new Page($video->where($wherelist)->total(), PHTURE_PAGE_SIZE, "pid/{$pid}");
		$page->set("head","个展示");
		$videos = $video->field('id,title,pic')->where($wherelist)->order("id desc")->limit($page->limit)->select();
		$this->assign("pros", $videos);
		$this->assign("fpage", $page->fpage(4,5,6,0,3));			
		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
	
	function show() {
		$video= D("video");
		$id = filter_var($_GET["id"],FILTER_VALIDATE_INT);
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			//广告图
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>6))->order('ord asc')->select();
			$this->assign('ad',$ad);
			//获取产品
			$vcolumn = D("vcolumn");
			$pdata=$video->where(array("id"=>$id))->find();
			if(!$pdata){
				$this->error("你现在访问的产品不存在或没有审核!", 3, "index/index");
			}
			
			/**展示栏目**/
 			$current = $vcolumn->field('id,path,audit')->where(array("id"=>$pdata['pid'],"display"=>1))->find();
			$cid = explode("-",$current['path']);
			$procol = $vcolumn->field('id,title')->order("ord asc")->where(array("id"=>$cid[1],"display"=>1))->select();
			$this->assign('colfive',$vcolumn->colfive($procol,B_URL.'/index/pid/')); 
			
			if($current["audit"]==1){
				$wherelist=array("pid"=>$current['id'], "audit"=>1);
				$twhere=array("pid"=>$current['id'], "audit"=>1,'top'=>1);
				$rwhere=array("pid"=>$current['id'], "audit"=>1,'recommend'=>1);
				$hwhere=array("audit"=>1, "pid"=>$current['id']);
			}else{
				$wherelist=array("pid"=>$current['id']);
				$twhere=array("pid"=>$current['id'],'top'=>1);
				$rwhere=array("pid"=>$current['id'],'recommend'=>1);
				$hwhere=array("pid"=>$current['id']);
			}
			/*置顶、推荐、热门*/		
			$this->assign("tp", $video->field('id,title,pic')->where($twhere)->order("id desc")->limit(6)->select());
			$this->assign("rp", $video->field('id,title,pic')->where($rwhere)->order("id desc")->limit(6)->select());
			$this->assign("hp", $video->field('id,title,pic')->where($hwhere)->order("views desc")->limit(6)->select());			
			
			/******显示全部分类关闭上方展示栏目并开启此代码
			$current = $vcolumn->field('id,path')->where(array("id"=>$pdata['pid'],"display"=>1))->find();
			$procol = $vcolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
			$this->assign('colfive',$vcolumn->colfive($procol,B_URL.'/index/pid/'));*****/		

			/*当前位置*/
			$locs=$vcolumn->field('id,title,description')->where(str_replace('-',',', $current["path"]).','.$current["id"])->order('path asc')->select();
			$this->assign("locs", $locs);
			
			//分配展示到模板
			$pdata["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $pdata["content"]);
			$this->assign("video", $pdata);
		}
		$this->assign('views',$video->field('id,views')->find($id));
		$video->where(array("id"=>$id))->update("views=views+1");
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
}