<?php 
class Alone {
	function index(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			//广告图
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>2))->order('ord asc')->select();
			$this->assign('ad',$ad);
			
			//轮播图
			$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>6))->find());

			//分配单页信息
			$acolumn = D('acolumn');
			$about = D("about");
			$pid = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
			$type = $acolumn->field('id,path,etitle,type,edescription')->where(array('id'=>$pid,'display'=>1))->find();
			if(!$type){
				$this->error("页面不存在或未审核",3,"index/index");
			}
			
			/*当前位置*/
			$locs=$acolumn->field('id,etitle,edescription')->where(str_replace('-',',', $type["path"]).','.$pid)->order('path asc')->select();
			$this->assign("locs", $locs);
			
			/*单页栏目*/
			//$cid = explode("-",$type['path']);
			$abtcol = $acolumn->field('id,etitle')->order("ord asc")->where(array("pid"=>1,"display"=>1))->select();
			$this->assign('col',$abtcol);
			
			/*显示全部分类关闭上方单页栏目并开启此代码
			$abtcol = $acolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
			$this->assign('colfive',$acolumn->colfive($abtcol,B_URL.'/index/pid/'));*/			
			
			if($type['type']==1){
				$aboutshow = $about->field('id,etitle,econtent')->where(array("pid"=>$pid,"audit"=>1))->find();			
				$aboutshow["econtent"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $aboutshow["econtent"]);
				$this->assign("aboutshow",$aboutshow);
			}else{
				$where = array("pid"=>$pid,"audit"=>1,"etitle !="=>'');
				$page = new Page($about->total($where),12,"/pid/".$pid);
				$aboutlist = $about->field('id,pic,etitle')->where($where)->limit($page->limit)->order('
				ord asc')->select();
				$this->assign('aboutlist',$aboutlist);
				$this->assign("fpage",$page->fpage(4,5,6));
			}			
			$this->assign("type",$type['type']);
		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
	
	function show(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			//广告图
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>2))->order('ord asc')->select();
			$this->assign('ad',$ad);
			
			//轮播图
			$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>6))->find());

			//分配单页信息
			$about = D("about");
			$id = filter_var($_GET["id"],FILTER_VALIDATE_INT);			
			$aboutshow = $about->field('id,pid,etitle,econtent')->where(array("id"=>$id,"audit"=>1))->find();
			if(!$aboutshow){
				$this->error("当前页面不存在或未审核",3,"index/index");
			}
			$aboutshow["econtent"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $aboutshow["econtent"]);
			$this->assign("aboutshow",$aboutshow);
			
			/**单页栏目**/
			$acolumn = D('acolumn');
			$path = $acolumn->field('id,path,title')->where(array("id"=>$aboutshow['pid'],"display"=>1))->find();
			$cid = explode("-",$path['path']);
			$abtcol = $acolumn->field('id,pid,etitle')->order("ord asc")->where(array("pid"=>1,"display"=>1))->select();
			$this->assign('col',$abtcol);

			/*显示全部分类关闭上方单页栏目并开启此代码
			$acolumn = D('acolumn');
			$path = $acolumn->field('id,path,title')->where(array("id"=>$aboutshow['pid'],"display"=>1))->find();
			$abtcol = $acolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
			$this->assign('colfive',$acolumn->colfive($abtcol,B_URL.'/index/pid/'));*/

			/*当前位置*/
			$locs=$acolumn->field('id,etitle,edescription')->where(str_replace('-',',', $path["path"]).','.$path["id"])->order('path asc')->select();
			$this->assign("locs", $locs);			

		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
	
	function contact(){
		if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {			
			//广告图
			$advert = D('advert');
			$ad = $advert->where(array('display'=>1,'wz'=>2))->order('ord asc')->select();
			$this->assign('ad',$ad);
			
			//轮播图
			$this->assign("ban1",D('banner')->where(array('display'=>1,'ord'=>11))->find());

			//分配单页信息
			$acolumn = D('acolumn');
			$about = D("about");
			$pid = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
			$type = $acolumn->field('id,path,etitle,type,edescription')->where(array('id'=>$pid,'display'=>1))->find();
			if(!$type){
				$this->error("页面不存在或未审核",3,"index/index");
			}
			
			/*当前位置*/
			$locs=$acolumn->field('id,etitle,edescription')->where(str_replace('-',',', $type["path"]).','.$pid)->order('path asc')->select();
			$this->assign("locs", $locs);
			
			/*单页栏目*/
			//$cid = explode("-",$type['path']);
			$abtcol = $acolumn->field('id,etitle')->order("ord asc")->where(array("pid"=>1,"display"=>1))->select();
			$this->assign('col',$abtcol);
			
			/*显示全部分类关闭上方单页栏目并开启此代码
			$abtcol = $acolumn->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
			$this->assign('colfive',$acolumn->colfive($abtcol,B_URL.'/index/pid/'));*/			
			
			if($type['type']==1){
				$aboutshow = $about->field('id,etitle,econtent')->where(array("pid"=>$pid,"audit"=>1))->find();			
				$aboutshow["econtent"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $aboutshow["econtent"]);
				$this->assign("aboutshow",$aboutshow);
			}else{
				$where = array("pid"=>$pid,"audit"=>1);
				$page = new Page($about->total($where),12,"/pid/".$pid);
				$aboutlist = $about->field('id,pic,etitle')->where($where)->limit($page->limit)->order('
				ord asc')->select();
				$this->assign('aboutlist',$aboutlist);
				$this->assign("fpage",$page->fpage(4,5,6));
			}			
			$this->assign("type",$type['type']);
		}
		$this->display(null, $_SERVER["REQUEST_URI"]);
	}
}