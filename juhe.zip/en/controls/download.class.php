<?php
	class Download{
		function index(){
			if(!$this->isCached(null, $_SERVER["REQUEST_URI"])) {
			$download = D("download");

			//分配单页栏目
			$id = filter_var($_GET["pid"],FILTER_VALIDATE_INT);
			$acolumn = D('acolumn');
			$abtcol = $acolumn->field('id,title')->order("ord asc")->where(array("id"=>$id,"display"=>1))->select();
			$this->assign('colfive',$acolumn->colfive($abtcol,B_APP.'/alone/index/pid/'));
			
			$page=new Page($download->total(),6);
			$page->set("head","个文件");
			$this->assign("down", $download->order("id desc")->limit($page->limit)->r_select(array("image",'name as imgname','id','picid')));
			$this->assign("fpage", $page->fpage(4,5,6,0,3));
			
			}
			$this->display(null, $_SERVER["REQUEST_URI"]);
		}
		
		//文件下载
		function down(){
			$download = D('download');
			$download->where(array("id"=>$_GET["id"]))->update("views=views+1");
			$download = $download->field('filename')->find($_GET['id']);
			$filename = PROJECT_PATH."/public/uploads/down/".$download['filename'];
			header("Content-Length:".filesize($filename));
			header('Content-Type:application/octet-stream');
			header('Content-Disposition:attachment;filename="'.$download['filename'].'"');
			readfile($filename);
		}
	}