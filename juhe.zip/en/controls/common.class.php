<?php
	class Common extends Action {
		function init(){
		//常量信息
		$this->assign("appname", APP_NAME);
		$this->assign("keywords", KEYWORD);
		$this->assign("description", DESCRIPTION);
		$this->assign("icp",ICP);
		$this->assign("copy",COPY);
		
		//页面导航
		$menu = D('menu');
		$globallink = $menu->field('id,etitle,url,target,pic,esummary')->order('ord asc')->where(array('pid'=>0,'display'=>1))->r_select(array("menu",'id,etitle,url,target','pid',array('men','ord asc','',"display=1")));
		$this->assign('globallink',$globallink);

		//焦点图
		$banner = D('banner');
		$ban = $banner->where(array('display'=>1,'ord'=>array(0,1,2,3,4,5)))->order('ord asc')->select();
		$this->assign('ban',$ban);
		
		//公告
		$time=strtotime(date("Y-m-d"))+60*60*24;
		$notice=D("notice")->field('id,etitle,color')->where('display="1" and etitle != "" and "'.$time.'" > starttime and ("'.$time.'" < endtime or endtime="0")')->order("ord asc")->select();
		$this->assign("notice", $notice);
		
		//联系方式
		$fun = D("fun")->where(array("id"=>1,"audit"=>1))->find();
		if($fun){
			$fun["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $fun["content"]);
			$this->assign("contact",$fun["content"]);
		}else{
			$this->assign("contact","管理员已取消显示");
		}
		
		//分配插件
		$activex = D('activex')->where(array('audit'=>1))->order('id asc')->select();
		$this->assign('activex',$activex);
		
		//友情链接
		$this->assign("links", D("flink")->field('id, webname,url,logo,list')->where(array("audit"=>1))->order("ord asc")->select());
		}		
	}