<?php
	class Search{
		function index(){
			$this->caching=0;
			$this->assign("appname", APP_NAME);
			$this->assign("keywords", KEYWORD);
			$this->assign("description", DESCRIPTION);
			$this->assign("icp",ICP);
			$this->assign("copy",COPY);
			
			//公告
			$time=strtotime(date("Y-m-d"))+60*60*24;
			$notice=D("notice")->field('id,title,color')->where('display="1" and "'.$time.'" > starttime and ("'.$time.'" < endtime or endtime="0")')->order("ord asc")->select();
			$this->assign("notice", $notice);
			
			//导航
			$menu = D('menu');
			$globallink = $menu->field('id,title,url,target')->order('ord asc')->where(array('pid'=>0,'display'=>1))->r_select(array("menu",'id,title,url,target','pid',array('men','ord asc','',"display=1")));
			$this->assign('globallink',$globallink);
			$this->assign('globallinktotal',$menu->total(array('pid'=>0,'display'=>1)));
			
			//焦点图
			$banner = D('banner');
			$ban = $banner->where(array('display'=>1,'ord'=>array(0,1,2,3,4,5)))->order('ord asc')->select();
			$this->assign('ban',$ban);

			//联系方式
			$fun = D("fun")->where(array("id"=>1,"audit"=>1))->find();
			if($fun){
				$fun["content"]=str_replace(array("&quot;", "&#039;"),array("\"", "'"), $fun["content"]);
				$this->assign("contact",$fun["content"]);
			}else{
				$this->assign("contact","管理员已取消显示");
			}

			//分配插件
			$activex = D('activex')->where(array('audit'=>1))->order('id asc')->select();
			$this->assign('activex',$activex);			
			
			//友情链接
			$this->assign("links", D("flink")->field('id, webname,url,logo,list')->where(array("audit"=>1))->order("ord asc")->select());	
			
			$serkey = stripslashes(htmlspecialchars($_POST["search"],ENT_QUOTES));
			$sers=!empty($serkey) ? $_POST : $_GET;
			
			$typevalue=filter_var($sers["sertype"],FILTER_VALIDATE_INT);
			$args="sertype/{$typevalue}/search/{$sers["search"]}";
			if(!empty($serkey)){
				$where=array("title"=>"%{$sers["search"]}%","audit"=>"1");
				$_SESSION['key'] = $serkey;
			}else{
				$args="sertype/{$typevalue}/search/".checkstr($_GET["search"]);
				$where=array("title"=>"%".checkstr($_GET["search"])."%","audit"=>"1");
			}
			if($sers["sertype"]==1){
				$artcol = D('column')->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
				$this->assign('colfive',D('column')->colfive($artcol,B_APP.'/article/index/pid/'));
				$article=D("article");
				$total=$article->where($where)->total();
				$page=new Page($total, ARTICLE_PAGE_SIZE, $args);
				$this->assign("searchs", $article->field('id,title')->where($where)->limit($page->limit)->select());
			}elseif($sers["sertype"]==2){
				$phcol = D('phcolumn')->field('id,title')->order("ord asc")->where(array("pid"=>0,"display"=>1))->select();
				$this->assign('colfive',D('phcolumn')->colfive($phcol,B_APP.'/photo/index/pid/'));			
				$photo=D("photo");
				$total=$photo->where($where)->total();
				$page=new Page($total, PHTURE_PAGE_SIZE, $args);
				$this->assign("searchs", $photo->field('id,title,pic,pid,posttime,summary')->where($where)->limit($page->limit)->select());
			}else{
				$this->error('搜索失败',3,'index/index');
			}
			$this->assign("sertype", $sers["sertype"]);			
			$this->assign("total", $total);	
			$this->assign("search", $_SESSION['key']);
			$this->assign("fpage", $page->fpage(4,5,6,0));
			$this->display();		
		}
	}