$(function(){
	$(".l-two").toggle(function(){
		$(this).parent().siblings().slideUp(300);
		$(this).text("+")		
	},function(){
		$(this).parent().siblings().slideDown(300);
		$(this).text("-")
	});
	
	$(".l-three").toggle(function(){

		$(this).parent().siblings().slideUp(300);
		$(this).text("+")		
	},function(){
		$(this).parent().siblings().slideDown(300);
		$(this).text("-")
	});	
	
	$(".l-four").toggle(function(){
		$(this).parent().siblings().slideUp(300);
		$(this).text("+")		
	},function(){
		$(this).parent().siblings().slideDown(300);
		$(this).text("-")
	});	
})
$(function(){
	$('.menu ul li').mouseover(function(){	
		$(this).find('.mtan').stop(true,true).show();
		$(this).children("a").addClass("cur");
	});
	$('.menu ul li').mouseleave(function(){	
		$(this).find('.mtan').stop(true,true).hide();
		$(this).children("a").removeClass("cur");
	});
	/*服务流程*/
	$("#fw").click(function(){
		$("body").append("<div class='fwlc'><div class='fwlc2'></div><div id='close'></div></div>");
	});
	$("#close").live("click",function(){
		$(".fwlc").remove();
	});
	/*付款*/
	$("#fk").click(function(){
		$("body").append("<div class='fwlc'><div class='fk'></div><div id='close'></div></div>");
	});
	$("#close").live("click",function(){
		$(".fwlc").remove();
	});	
})
