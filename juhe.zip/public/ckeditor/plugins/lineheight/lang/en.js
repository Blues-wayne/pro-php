﻿CKEDITOR.plugins.setLang('lineheight', 'en', {
    label: 'lineheight',
    panelTitle: 'line-height',
    panelTitle: 'line-height'
});