﻿CKEDITOR.plugins.setLang('lineheight', 'zh-cn', {
    label: '行距',
    panelTitle: '行距',
    panelTitle: '行距'
});